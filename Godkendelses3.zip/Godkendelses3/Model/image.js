// User picture
class Image {
    constructor(type, size, owner){
        this.type = type
        this.size = size
        this.owner = owner
    }
}

module.exports = Image