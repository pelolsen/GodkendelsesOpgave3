// I use an array as a form of an index so the users can chose their interrests
let InterrestArray = []
InterrestArray = ["Netflix", "Sports", "Party", "Business", "Children", "Hygge"];

module.exports = InterrestArray;
