let InterrestArray = []
InterrestArray = ["Netflix", "Sports", "Party", "Business", "Children", "Hygge"];

module.exports = InterrestArray;
